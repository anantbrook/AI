@echo off
color 0A
title Installing AiderWeb Advanced dependencies...

echo =======================================================
echo          Installing Backend Requirements
echo =======================================================
cd backend
pip install -r requirements.txt
if %errorlevel% neq 0 (
    echo.
    echo ERROR: Failed to install Python dependencies. Ensure Python is installed.
    pause
    exit /b %errorlevel%
)
cd ..

echo.
echo =======================================================
echo          Installing Frontend Requirements
echo =======================================================
cd frontend
call npm install
if %errorlevel% neq 0 (
    echo.
    echo ERROR: Failed to install Node dependencies. Ensure NodeJS is installed.
    pause
    exit /b %errorlevel%
)

echo.
echo =======================================================
echo               Building Frontend
echo =======================================================
call npm run build
if %errorlevel% neq 0 (
    echo.
    echo ERROR: Failed to build the frontend.
    pause
    exit /b %errorlevel%
)
cd ..

echo.
echo =======================================================
echo      INSTALLATION COMPLETE! YOU CAN NOW RUN START.bat
echo =======================================================
pause
